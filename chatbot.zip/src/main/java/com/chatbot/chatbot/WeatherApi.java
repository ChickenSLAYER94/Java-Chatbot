package com.chatbot.chatbot;

import java.util.Date;

import net.aksingh.owmjapis.api.APIException;
import net.aksingh.owmjapis.core.OWM;
import net.aksingh.owmjapis.model.CurrentWeather;

public class WeatherApi {
	//creating static variable which can be accessed by all method  
	public static OWM owm = new OWM("ef5af4a02e04c2b656d0b8573d9f88ea");
	  
	  
	//this method will return min temperature of the city
	public String temperatureMin(String x) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		return "The minimum temperature: "+(cwd.getMainData().getTempMin()-273.15)+"\u00B0"+"C";
	}
	
	//this method will return max temperature of the city
	public String temperatureMax(String x) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		return "The maximum temperature: "+(cwd.getMainData().getTempMax()-273.15)+"\u00B0"+"C";
//		return "sfsdbs"+(cwd.getDateTime().getDay());
	}
	
	//this method will return humidity of the city
	public String humidity(String x) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		return "Humidity: "+(cwd.getMainData().getHumidity())+"%";
	}
	
	//this method will return atmospheric pressure of the city
	public String atmosPressure(String x) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		return "Pressure: "+(cwd.getMainData().getPressure())+"Pa";
	}
	
	//cloth recommendation method
	public String cloth(String x) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		if (( cwd.getMainData().getTempMin()-273.15) > 20) {
			 x = "We suggest you to wear T-Shirts, Shorts and Sneakers for the temperature of "+x.substring(0, 1).toUpperCase()+x.substring(1)+" is "+(cwd.getMainData().getTempMin()-273.15)+"\u00B0"+"C";
		return x;
		}else if (( cwd.getMainData().getTempMin()-273.15) < 20) 
			x = "We suggest you to wear Jacket, Sweatshirt, Pants and boots for the temperature of " +x.substring(0, 1).toUpperCase()+x.substring(1)+" is "+(cwd.getMainData().getTempMin()-273.15)+"\u00B0"+"C";
		return x;
		
	}
	
	//cloth recommendation method with DATE
	public String datecloth(String x, Date y) throws APIException {
		CurrentWeather cwd = owm.currentWeatherByCityName(x);
		cwd.setDateTime(y);
		if (( cwd.getMainData().getTempMin()-273.15) > 10) {
			 x = "We suggest you to wear T-Shirts, Shorts and Sneakers for the temperature of "+x.substring(0, 1).toUpperCase()+x.substring(1)+" is "+(cwd.getMainData().getTempMin()-273.15)+"\u00B0"+"C";
			 return x;
		}else if (( cwd.getMainData().getTempMin()-273.15) < 10)
				x = "We suggest you to wear Jacket, Sweatshirt, Pants and boots for the temperature of " +x.substring(0, 1).toUpperCase()+x.substring(1)+" is "+(cwd.getMainData().getTempMin()-273.15)+"\u00B0"+"C";
			return x;
		}

		
	//display city name
	public String cityName(String x) {
		return "City Name: "+ x.substring(0, 1).toUpperCase()+x.substring(1);
		
	}
	
	
		
}