package com.chatbot.chatbot;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import net.aksingh.owmjapis.api.APIException;


public class ChatBot extends JFrame{
	private JTextArea chatArea = new JTextArea();
	private JTextField chatField = new JTextField();
	private JButton btn =new JButton();
	private JLabel l =new JLabel();
	public ChatBot() {

		final ArrayList<String> clothUse = new ArrayList<String>( );
		final ArrayList<String> cityN = new ArrayList<String>( );
		final ArrayList<String> humidity = new ArrayList<String>( );
		final ArrayList<String> atmosPressure = new ArrayList<String>( );
		//Creating chat box with user input box.
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setSize(750, 650);
		frame.getContentPane().setBackground(new java.awt.Color(17, 30, 108));
		frame.setTitle("Weather chatbot");
		frame.add(chatArea);
		frame.add(chatField);
		
		//for text area
		chatArea.setSize(750,500);
		chatArea.setLocation(1 ,1);
		
		//for text field
		chatField.setSize(550, 20);
		chatField.setLocation(1, 550);
		
		//layout decoration
		//change background are color
		chatArea.setBackground(Color.BLACK);
			
		//add button to the frame
		frame.add(btn);
		l.setText("SEND");
		btn.setBackground(new java.awt.Color(0, 128, 255));
		
		//change button size, location and color
		btn.add(l);
		btn.setSize(250,20);
		btn.setLocation(550,550);
		final WeatherApi ap0 = new WeatherApi();
		final WeatherApi ap1 = new WeatherApi();
		final WeatherApi ap2 = new WeatherApi();
		final WeatherApi ap3 = new WeatherApi();
		final WeatherApi ap4 = new WeatherApi();
		
		btn.addActionListener(new ActionListener() {			
			//Here it takes our input and give suitable output
			public void actionPerformed(ActionEvent e) {
				
				boolean isValid = false;
				//this will send message when send button is clicked
				if(e.getSource()==btn) {                         
					String humanInput=chatField.getText().toLowerCase();
					chatArea.setForeground(Color.GREEN);
					chatArea.append("Me: "+ humanInput + "\n");
					chatField.setText("");
					
					
					if(humanInput.contains("hi") || humanInput.contains("hello")) {
						botResponse("Hi there, how are you today?");
						isValid = true;
					}
					else if(humanInput.contains("i am fine")) {
						botResponse("Glad to hear. How can I help you?");
						isValid = true;
					}
					else if(humanInput.contains("what is your name")) {
						botResponse("I am Jarvis. How can i help you?");
						isValid = true;
					}
					else if(humanInput.contains("give clothing recommendation for trip")) {
						botResponse("For homy many location and how many days");
						isValid = true;
					}
					
					else if(humanInput.contains("5 location 3 days")) {
						botResponse("Please input all the cities with and seperate them with comma.");
						isValid = true;
					}
					else {					// input should be "   city1,city2,city3,city4,city5,trip"
						isValid=true;
						String splitted = humanInput;
						String Splittedarray[] = splitted.split(",");
						System.out.println(Arrays.toString(Splittedarray));
				
						System.out.println(Splittedarray[0]);
						System.out.println(Splittedarray[1]);
						System.out.println(Splittedarray[2]);
						System.out.println(Splittedarray[3]);
						System.out.println(Splittedarray[4]);
						
//						Weather information of 1 location  
							int counterr = 0;																					//reading file
								
								while(counterr<readRecord().size()) {	//while1
		

									if(Splittedarray[0].toLowerCase().equals(readRecord().get(counterr).toLowerCase())) {       //if text file has matching info with human input array                  
										WeatherApi ap = new WeatherApi();															//defining new weather api
									isValid=true;
									try {
										isValid=true;
										String clothUsee = ap.cloth(readRecord().get(counterr));
										clothUse.add(clothUsee);
										String cityNn = ap.cityName(readRecord().get(counterr));
										cityN.add(cityNn);
										String humidityy = ap.humidity(readRecord().get(counterr));
										humidity.add(humidityy);
										String atmosPressuree = ap.atmosPressure(readRecord().get(counterr));
										atmosPressure.add(atmosPressuree);
									
										//display weather information
										botResponse(cityN.get(0));
										botResponse(humidity.get(0));														
								 		botResponse(atmosPressure.get(0));
										botResponse(clothUse.get(0));
											
										
										isValid = true;
										break;
										
									} catch (APIException e1) {
//										invalid input 
										isValid = false;
										
									}
								}	
									
									counterr++;
									}
//								Weather information of 2 location  
								counterr=0;
								while(counterr<readRecord().size()) {		
									

									if(Splittedarray[1].toLowerCase().equals(readRecord().get(counterr).toLowerCase())) {       //if text file has matching info with human input array                  
										WeatherApi ap = new WeatherApi();															//defining new weather api
									isValid=true;
									try {
										String clothUsee = ap.cloth(readRecord().get(counterr));
										clothUse.add(clothUsee);
										String cityNn = ap.cityName(readRecord().get(counterr));
										cityN.add(cityNn);
										String humidityy = ap.humidity(readRecord().get(counterr));
										humidity.add(humidityy);
										String atmosPressuree = ap.atmosPressure(readRecord().get(counterr));
										atmosPressure.add(atmosPressuree);
										
									
										botResponse(cityN.get(1));
										botResponse(humidity.get(1));														
										botResponse(atmosPressure.get(1));
										botResponse(clothUse.get(1));
											
										
										isValid = true;
										break;
										
									} catch (APIException e1) {
										isValid = false;
										
										}
									}	
									counterr++;
									}
//								Weather information of 3 location  
								counterr=0;
								while(counterr<readRecord().size()) {	//while3
									isValid = true;

									if(Splittedarray[2].toLowerCase().equals(readRecord().get(counterr).toLowerCase())) {       //if text file has matching info with human input array                  
										WeatherApi ap = new WeatherApi();															//defining new weather api
									isValid=true;
									try {
										
										isValid=true;
										String clothUsee = ap.cloth(readRecord().get(counterr));
										clothUse.add(clothUsee);
										String cityNn = ap.cityName(readRecord().get(counterr));
										cityN.add(cityNn);
										String humidityy = ap.humidity(readRecord().get(counterr));
										humidity.add(humidityy);
										String atmosPressuree = ap.atmosPressure(readRecord().get(counterr));
										atmosPressure.add(atmosPressuree);
										
										//display weather information
										botResponse(cityN.get(2));
										botResponse(humidity.get(2));														
										botResponse(atmosPressure.get(2));
										botResponse(clothUse.get(2));
											
										
										isValid = true;
										break;
										
									} catch (APIException e1) {
										isValid = false;
										
										}
									}	
									counterr++;
									}
								
//								Weather information of 4 location  
								counterr=0;
								while(counterr<readRecord().size()) {		//while4
									
									isValid = true;
									if(Splittedarray[3].toLowerCase().equals(readRecord().get(counterr).toLowerCase())) {       //if text file has matching info with human input array                  
										WeatherApi ap = new WeatherApi();															//defining new weather api
									isValid=true;
									try {
										
										isValid=true;
										String clothUsee = ap.cloth(readRecord().get(counterr));
										clothUse.add(clothUsee);
										String cityNn = ap.cityName(readRecord().get(counterr));
										cityN.add(cityNn);
										String humidityy = ap.humidity(readRecord().get(counterr));
										humidity.add(humidityy);
										String atmosPressuree = ap.atmosPressure(readRecord().get(counterr));
										atmosPressure.add(atmosPressuree);
									
										//display weather information
										botResponse(cityN.get(3));
										botResponse(humidity.get(3));														
										botResponse(atmosPressure.get(3));
										botResponse(clothUse.get(3));
											
										
										isValid = true;
										break;
										
									} catch (APIException e1) {
										isValid = false;
										
										}
									}	
									counterr++;
									}
								
//								Weather information of 5 location  
								counterr=0;
								while(counterr<readRecord().size()) {		
									isValid = true;
									if(Splittedarray[4].toLowerCase().equals(readRecord().get(counterr).toLowerCase())) {                       
										WeatherApi ap = new WeatherApi();															
									isValid=true;
									try {
										
										isValid=true;
										String clothUsee = ap.cloth(readRecord().get(counterr));
										clothUse.add(clothUsee);
										String cityNn = ap.cityName(readRecord().get(counterr));
										cityN.add(cityNn);
										String humidityy = ap.humidity(readRecord().get(counterr));
										humidity.add(humidityy);
										String atmosPressuree = ap.atmosPressure(readRecord().get(counterr));
										atmosPressure.add(atmosPressuree);
									
										//display weather information
										botResponse(cityN.get(4));
										botResponse(humidity.get(4));														
										botResponse(atmosPressure.get(4));
										botResponse(clothUse.get(4));
											
										
										isValid = true;
										break;
										
									} catch (APIException e1) {
										isValid = false;
										
									}
								}	
									counterr++;
									}							
					}
					if(isValid==false) {
						int rand = (int)(Math.random()*3+1);
						if(rand==1) {
							botResponse("Please try again invalid data input.");
						} else if(rand ==2) {
							botResponse("Can you be more specific");
						} else if(rand == 1) {
							botResponse("Cannot find you data in my database");
						}
					}
			}
							
			
			}
			//method to print out bot response
			public void botResponse(String s) {                          
				chatArea.append("Jarvis: "+s+"\n");         
			}
		}
		);
		
}
	
	private static Scanner x;
	
	public static void main(String args[]) {
		readRecord();
		new ChatBot();
	}
	public static ArrayList<String> readRecord()
	{
		ArrayList<String> cityName = new ArrayList<String>();
		String eachCityName = "";
	
		try {
			x = new Scanner(new File("citiesName.txt"));
			
			while(x.hasNext())
			{
				eachCityName = x.next();
				cityName.add(eachCityName);
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return cityName;
	}
}