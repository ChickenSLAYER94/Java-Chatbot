package com.chatbot.chatbot;

import org.junit.Test;

import junit.framework.TestCase;
import net.aksingh.owmjapis.api.APIException;

public class ChatBotTest extends TestCase {
	//creating instance of class 
	WeatherApi weather = new WeatherApi();
	
	//testing temperatureMax() method starts
	@Test
	 public void testTemperatureMax() throws APIException{
	      String city="cairo";
	      String actual= weather.temperatureMax(city);
	      String expected="The maximum temperature: 18.33000000000004°C";
	      assertNotNull(expected,actual);
	 }
	
	@Test
	public void testTemperatureMax1() throws APIException{
	    String city="cork";
	    String actual= weather.temperatureMax(city);
	    String expected="The maximum temperature: 26.0°C";
	    assertEquals(expected,actual);
	}
	
	@Test
	public void testTemperatureMax2() throws APIException{
	    String city="Surkhet";
	    String actual= weather.temperatureMax(city);
	    String expected="The maximum temperature: 34.77000000000004°C";
	    assertTrue(expected.equals(actual));
	}
	//testing temperatureMax() method ends
	
	//testing temperatureMin() method starts
	@Test
	 public void testTemperatureMin() throws APIException{
	      String city="Kenya";
	      String actual= weather.temperatureMin(city);
	      String expected="The minimum temperature: 32.26000000000005°C";
		  assertEquals(expected,actual);   
	 }
	
	@Test
	public void testTemperatureMin1() throws APIException{
	    String city="Biratnagar";
	    String actual= weather.temperatureMin(city);
	    String expected="The minimum temperature: 36.72000000000003°C";
	    assertTrue(expected.equals(actual));
	}
	
	@Test
	public void testTemperatureMin2() throws APIException{
	    String city="Osaka";
	    String actual= weather.temperatureMin(city);
	    String expected="The minimum temperature: 20.5645°C";
	    assertFalse(expected.equals(actual));
	}
	//testing temperatureMin() method ends
	
	//testing humidity() method starts
	@Test
	 public void testHumidity() throws APIException{
	      String city="london";
	      String actual= weather.humidity(city);
	      String expected="Humidity: 57.0%";
		  assertNotSame(expected,actual);   
	 }
	
	@Test
	public void testHumidity1() throws APIException{
	    String city="Istanbul";
	    String actual= weather.humidity(city);
	    String expected="Humidity: 63.0%";
	    assertTrue(expected.equals(actual));
	}
	
	@Test
	public void testHumidity2() throws APIException{
	    String city="Melbourne";
	    String actual= weather.humidity(city);
	    String expected="Humidity: 69.54%";
	    assertFalse(expected.equals(actual));
	}
	//testing humidity() method ends
	
	//testing atmosPressure() method starts
	@Test
	 public void testPressure() throws APIException{
	      String city="Sydney";
	      String actual= weather.atmosPressure(city);
	      String expected="Pressure: 1028.0Pa";
		  assertEquals(expected,actual);   
	 }
	
	@Test
	public void testPressure1() throws APIException{
	    String city="Istanbul";
	    String actual= weather.atmosPressure(city);
	    String expected="Pressure: 1055.0Pa";
	    assertNotNull(expected.equals(actual));
	}
	
	@Test
	public void testPressure2() throws APIException{
	    String city="Mumbai";
	    String actual= weather.atmosPressure(city);
	    String expected="Pressure: 1008.0Pa";
	    assertTrue(expected.equals(actual));
	}
	//testing atmosPressure() method starts
	
	//testing cloth() method starts
	@Test
	public void testcloth() throws APIException{
	    String city="Macau";
	    String actual= weather.cloth(city);
	    String expected="We suggest you to wear T-Shirts, Shorts and Sneakers for the temperature of Macau is 26.0°C";
	    assertTrue(expected.equals(actual));
	}
	
	@Test
	 public void testcloth1() throws APIException{
	      String city="Singapore";
	      String actual= weather.cloth(city);
	      String expected="We suggest you to wear T-Shirts, Shorts and Sneakers for the temperature of Singapore is 25.560000000000002°C";
	      assertNotNull(expected,actual);
	 }
	
	@Test
	public void testcloth2() throws APIException{
	    String city="Munich";
	    String actual= weather.cloth(city);
	    String expected="We suggest you to wear T-Shirts, Shorts and Sneakers for the temperature of Munich is 12.78000000000003°C";
	    assertEquals(expected,actual);
	}
	//testing cloth() method ends.
	
}
